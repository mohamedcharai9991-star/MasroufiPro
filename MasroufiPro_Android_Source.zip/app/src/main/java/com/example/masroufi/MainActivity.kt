package com.example.masroufi

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.*
import android.widget.*
import java.util.*

data class Tx(val id: Long, val amount: Double, val title: String, val category: String, val income: Boolean, val date: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("masroufi", Context.MODE_PRIVATE) }
    private val txs = mutableListOf<Tx>()
    private var hourly = 17.92
    private lateinit var content: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        dashboard()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 30, 22, 18)
        setBackgroundColor(Color.rgb(246,248,251))
    }

    private fun title(t:String): TextView = TextView(this).apply {
        text=t; textSize=28f; setTextColor(Color.rgb(25,35,50))
        setPadding(0,0,0,18)
    }

    private fun btn(t:String, action:()->Unit) = Button(this).apply {
        text=t; textSize=15f; setOnClickListener { action() }
    }

    private fun money(v:Double) = "%.2f".format(Locale.US, v)

    private fun dashboard() {
        val root=base()
        root.addView(title("مصروفي Pro"))
        val income=txs.filter{it.income}.sumOf{it.amount}
        val expense=txs.filter{!it.income}.sumOf{it.amount}
        val card=TextView(this).apply {
            text="الدخل\n${money(income)}\n\nالمصاريف\n${money(expense)}\n\nالرصيد\n${money(income-expense)}"
            textSize=20f; setTextColor(Color.DKGRAY); setBackgroundColor(Color.WHITE); setPadding(28,25,28,25)
        }
        root.addView(card, LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=18})
        root.addView(btn("➕ إضافة مصروف"){ addTx(false) })
        root.addView(btn("💰 إضافة دخل"){ addTx(true) })
        root.addView(btn("📋 سجل العمليات"){ history() })
        root.addView(btn("💼 حساب الراتب والساعات الإضافية"){ salary() })
        root.addView(btn("📊 الإحصائيات"){ stats() })
        root.addView(btn("⚙️ الإعدادات"){ settings() })
        content=root; setContentView(root)
    }

    private fun addTx(isIncome:Boolean) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val name=EditText(this).apply{hint=if(isIncome)"مثلاً: الراتب" else "مثلاً: مشتريات"}
        val amount=EditText(this).apply{hint="المبلغ"; inputType=2 or 8192}
        val cat=EditText(this).apply{hint="التصنيف: أكل، نقل، كراء..."}
        box.addView(name); box.addView(amount); if(!isIncome) box.addView(cat)
        AlertDialog.Builder(this).setTitle(if(isIncome)"إضافة دخل" else "إضافة مصروف").setView(box)
            .setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
                val a=amount.text.toString().replace(",",".").toDoubleOrNull()?:return@setPositiveButton
                val d=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date())
                txs.add(Tx(System.currentTimeMillis(),a,name.text.toString().ifBlank{if(isIncome)"دخل" else "مصروف"},cat.text.toString().ifBlank{"عام"},isIncome,d))
                save(); dashboard()
            }.show()
    }

    private fun history() {
        val root=base(); root.addView(title("سجل العمليات"))
        if(txs.isEmpty()) root.addView(TextView(this).apply{text="لا توجد عمليات بعد.";textSize=18f})
        else txs.sortedByDescending{it.id}.forEach{t->
            val row=TextView(this).apply{
                text=(if(t.income)"💰 دخل" else "💸 مصروف")+"  |  ${t.title}\n${money(t.amount)}  •  ${t.category}  •  ${t.date}"
                textSize=16f; setPadding(16,18,16,18); setBackgroundColor(Color.WHITE)
                setOnLongClickListener{ txs.removeIf{x->x.id==t.id}; save(); history(); true }
            }
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=8})
        }
        root.addView(btn("⬅ العودة"){dashboard()}); content=root;setContentView(root)
    }

    private fun salary() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val rate=EditText(this).apply{hint="أجر الساعة";setText(hourly.toString());inputType=2 or 8192}
        val normal=EditText(this).apply{hint="عدد الساعات العادية";inputType=2 or 8192}
        val extra=EditText(this).apply{hint="الساعات الإضافية";inputType=2 or 8192}
        val mult=EditText(this).apply{hint="معامل الساعات الإضافية (مثلاً 1.25 أو 1.5)";setText("1.5");inputType=2 or 8192}
        box.addView(rate);box.addView(normal);box.addView(extra);box.addView(mult)
        AlertDialog.Builder(this).setTitle("حاسبة الراتب").setView(box).setNegativeButton("إلغاء",null)
            .setPositiveButton("احسب"){_,_->
                hourly=rate.text.toString().replace(",",".").toDoubleOrNull()?:17.92
                val n=normal.text.toString().replace(",",".").toDoubleOrNull()?:0.0
                val e=extra.text.toString().replace(",",".").toDoubleOrNull()?:0.0
                val m=mult.text.toString().replace(",",".").toDoubleOrNull()?:1.5
                val total=n*hourly+e*hourly*m
                AlertDialog.Builder(this).setTitle("النتيجة").setMessage("الراتب الأساسي: ${money(n*hourly)}\nالساعات الإضافية: ${money(e*hourly*m)}\n\nالإجمالي: ${money(total)}").setPositiveButton("حسنًا",null).show()
            }.show()
    }

    private fun stats() {
        val expenses=txs.filter{!it.income}.groupBy{it.category}.mapValues{it.value.sumOf{x->x.amount}}.toList().sortedByDescending{it.second}
        val msg=if(expenses.isEmpty())"لا توجد مصاريف بعد." else expenses.joinToString("\n"){ "• ${it.first}: ${money(it.second)}" }
        AlertDialog.Builder(this).setTitle("📊 إحصائيات المصاريف").setMessage(msg).setPositiveButton("حسنًا",null).show()
    }

    private fun settings() {
        AlertDialog.Builder(this).setTitle("الإعدادات").setMessage("مصروفي Pro 2.0\nالعملة الافتراضية: درهم\nلحذف عملية: اضغط عليها مطولاً من سجل العمليات.").setPositiveButton("حسنًا",null).show()
    }

    private fun save() {
        val s=txs.joinToString("\n"){listOf(it.id,it.amount,it.title,it.category,it.income,it.date).joinToString("|")}
        prefs.edit().putString("txs",s).apply()
    }

    private fun load() {
        prefs.getString("txs","")!!.lines().filter{it.isNotBlank()}.forEach{
            val p=it.split("|"); if(p.size>=6) txs.add(Tx(p[0].toLong(),p[1].toDouble(),p[2],p[3],p[4].toBoolean(),p[5]))
        }
    }
}
